import sys
import os

RESOURCE_DIR = os.path.abspath(r'F:\OneDrive\课件\人工智能\final\Gomoku-XYH19\resources')
'''
if getattr(sys, 'frozen', False): #是否Bundle Resource
    RESOURCE_DIR = sys._MEIPASS+'/resources'
'''